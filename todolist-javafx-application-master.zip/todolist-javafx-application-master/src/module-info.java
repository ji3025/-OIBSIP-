module TODOList {
    requires javafx.controls;
    requires javafx.fxml;
    requires jlfgr;

    opens com.kushwahatechnologies.todolist;
}