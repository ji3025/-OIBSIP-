# TODOList JavaFX Application
Simple application which manages your todo items.

## Snapshots

![1. main_window](https://github.com/SandeepKushwaha/todolist-javafx-application/blob/master/snaps/sample1.PNG)

![2. create new TODO.](https://github.com/SandeepKushwaha/todolist-javafx-application/blob/master/snaps/sample2.PNG)

![3. Menu Bar.](https://github.com/SandeepKushwaha/todolist-javafx-application/blob/master/snaps/sample3.png)

![4. Short Item for Today's.](https://github.com/SandeepKushwaha/todolist-javafx-application/blob/master/snaps/sample4.PNG)

![5. Delete Context Menu.](https://github.com/SandeepKushwaha/todolist-javafx-application/blob/master/snaps/sample5.PNG)

![6. Delete Confirmation.](https://github.com/SandeepKushwaha/todolist-javafx-application/blob/master/snaps/sample6.PNG)
